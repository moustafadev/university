#include <iostream>

using namespace std;
struct Node
{
    int item;
    Node *next;
};

void insertfirst(int length){

}



int main(){

    return 0;
}